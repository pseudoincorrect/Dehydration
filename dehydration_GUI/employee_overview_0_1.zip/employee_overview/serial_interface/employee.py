import time

###############################################################################
## Employee class
##
class Employee(object):
    def __init__(self, dehydration = 0, temperature = 0,
                                humidity = 0, name = "no name", parent=None):
        self.name          = name
        self.dehydration   = dehydration
        self.temperature   = temperature
        self.humidity      = humidity
        self.last_activity = time.time()

    def update_data(dehydration, temperature, humidity, name = " "):
        self.name          = name
        self.dehydration   = dehydration
        self.temperature   = temperature
        self.humidity      = humidity
        self.last_activity = time.time()

    def update_name(name):
        self.name = name

###############################################################################
## end class Employee #########################################################
###############################################################################

###############################################################################
## Employee List class
##
class EmployeeList(object):
    def __init__(self, parent=None):
        self.employee_list = list()

