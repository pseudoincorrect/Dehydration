import serial
from . import serial_constants as S_C
from . import serial_interface as S_I
from time import sleep


###############################################################################
## SET LED
## msg example : cmd, eemployee/server=3, led=1
## SET_LED,0003,0001   (e_0003_0001)
##
def nrf_set_led(nrf_serial, server, val):
	server_str  = str(server).zfill(S_C.SERVER_LENGHT)
	if (val == True):
		led_val = 1
	else:
		led_val = 0
	val_str     = str(led_val).zfill(S_C.VAL_LENGHT)
	msg_to_send = str(S_C.SET_LED) + str(server_str) + str(val_str) + '\r'
	return_msg  = S_I.serial_send_read_poll( nrf_serial, msg_to_send)
	return return_msg

###############################################################################
## GET Dehydration
## msg example : cmd, employee/server=3, dummybits=0000
## GET_DEHYDRATION,0003,0000   (b_0003_0000)
##
def nrf_get_dehydration(nrf_serial, server):
	server_str  = str(server).zfill(S_C.SERVER_LENGHT)
	val_str     = str(0).zfill(S_C.VAL_LENGHT)
	msg_to_send = str(S_C.GET_DEHYDRATION) +  str(server_str) + \
				  										str(val_str) + '\r'
	return_msg  = S_I.serial_send_read_poll(nrf_serial, msg_to_send)
	print ("return_msg = ", return_msg)
	str_begin   = S_C.CMD_LENGHT + S_C.SERVER_LENGHT
	str_end     = S_C.CMD_LENGHT + S_C.SERVER_LENGHT + S_C.VAL_LENGHT
	dehy_str    = return_msg[str_begin : str_end]
	dehy        = 0
	if (dehy_str):
		dehy = int(dehy_str)
	else:
		print("something when wrong in get_dehydration")
	return dehy

###############################################################################
## GET Node count
## msg example : cmd, edummybits=0000_0000, '\r'
## GET_NODES,0000,0000   (b_0003_0000), '\r'
##
def nrf_get_nodes_cnt(nrf_serial):
	msg_to_send    = str(S_C.GET_NODES) + '0000' + '0000' + '\r'
	return_msg     = S_I.serial_send_read_poll( nrf_serial, msg_to_send)
	str_begin      = S_C.CMD_LENGHT + S_C.SERVER_LENGHT
	str_end        = S_C.CMD_LENGHT + S_C.SERVER_LENGHT + S_C.VAL_LENGHT
	node_count_str = return_msg[str_begin : str_end]
	node_count     = 0
	if (node_count_str):
		node_count = int(node_count_str)
	else:
		print("something when wrong in get_node")
	return node_count
