import serial
from queue            import Queue
from threading        import Lock, Thread
from serial_interface import serial_constants   as S_C
from serial_interface import nrf_commands_funct as C_F
from serial_interface import serial_interface   as S_I


###############################################################################
## Serial class
##
class NrfSerial(object):
    def __init__(self, parent=None):
        self.serial_mutex  = Lock()
        self.serial_read_t = None
        self.nrf_ser       = None
        self.serial_queue  = Queue()


    ## Test and Connect the serial UART connection
    def connect_nrf(self):
        if (self.is_serial_connected()):
            print("nrf already connected")
            self.start_thread_serial_read()
            return 1
        else:
            self.get_nrf52()
            if (self.is_serial_connected()):
                self.start_thread_serial_read()
                return 1
            else:
                return 0

    ## Checke whether the serial is still connected
    def is_serial_connected(self):
        if (self.nrf_ser != None):
            self.serial_mutex.acquire()
            r_msg =  S_I.test_connection(self.nrf_ser)
            self.serial_mutex.release()
            if (r_msg):
                return True
            else:
                self.nrf_ser = None
                return False
        else:
            return False

    ## Get the port and create a UART serial instance
    def get_nrf52(self):
        nrf_ser_port = S_I.get_port()
        if (nrf_ser_port == None):
            self.nrf_ser = None
            return None
        else:
            self.nrf_ser = serial.Serial(nrf_ser_port, 115200, timeout=0.2)
        return 1

    ## start the serial listening thread
    def start_thread_serial_read(self):
        if ((self.serial_read_t is None) or (not self.serial_read_t.isAlive())):
            self.serial_read_t = Thread(target=self.thread_serial_read)
            self.serial_read_t.daemon = True
            self.serial_read_t.start()

    ## Serial listening infinite Thread function
    def thread_serial_read(self):
        while (True):
            self.serial_mutex.acquire()
            ret_val = self.read_serial()
            self.serial_mutex.release()
            if (ret_val == -1):
                break

    ## Serial listening function
    def read_serial(self):
        ret_val, ret_msg = S_I.read(self.nrf_ser)
        if (ret_msg):
            # print("message", ret_msg);
            self.serial_queue.put(ret_msg)
        return ret_val

    ## Send a test serial message
    def start_thread_send_dummy(self):
        serial_send_t = Thread(target=self.thread_send_dummy)
        serial_send_t.daemon = True
        serial_send_t.start()

    ## Send a test serial message
    def thread_send_dummy(self):
        if (self.is_serial_connected()):
            self.serial_mutex.acquire()
            msg_to_send = "b je suis un dummy message !\r"
            return_msg  = S_I.send_read_poll(self.nrf_ser, msg_to_send)
            self.serial_mutex.release()

    ## Send a test serial message
    def send_dummy(self):
        self.start_thread_send_dummy()

###############################################################################
## end class nrfSerial ########################################################
###############################################################################
