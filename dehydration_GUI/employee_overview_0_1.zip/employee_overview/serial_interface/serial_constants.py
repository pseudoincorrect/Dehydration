################################################################
## UART packet sections sizes in char
##
CMD_LENGHT 	  = 1 # 1 char for the command
SERVER_LENGHT = 4 # 4 chars for the server index number
VAL_LENGHT 	  = 4 # 4 chars for the val number

I_ADD  = 0
I_CMD  = 12
I_DEH  = 13
I_HUM  = 17
I_TEM  = 21
DATA_S = 4

################################################################
## Port Test constant messages
##
TEST_MSG        = 'a\r'
ANSWER_MSG      = 'yes\n'

