import sys
from time import sleep
from PyQt5 import QtGui, QtWidgets, QtCore
from PyQt5.QtWidgets import QApplication, QMainWindow
from GUI.Employee_overview_ui import Ui_Employees_Overview
from serial_interface.overview_processing import OverviewProcessing
from threading        import Lock, Thread


###############################################################################
## Main GUI window
##
class MyMainWindow(QMainWindow, Ui_Employees_Overview):
	def __init__(self, parent=None):
		super(MyMainWindow, self).__init__(parent=None)
		#######################################################################
		## general setting
		self.NUMBER_OF_EMPLOYEE = 100
		#######################################################################
		self.setupUi(self)

		self.buttonGroup = QtWidgets.QButtonGroup(self)
		self.buttonGroup.buttonClicked.connect(self.handleButtonClicked)

		# Windows Icon setting-up
		icon = QtGui.QIcon()
		icon.addPixmap(QtGui.QPixmap("GUI/gui_image/drop_icon.jpg"),
		               					    QtGui.QIcon.Normal, QtGui.QIcon.On)
		self.setWindowIcon(icon)
		# Windows image setting-up
		QPixmap_path = "GUI/gui_image/water_bottle.jpg"
		self.LB_image.setPixmap(QtGui.QPixmap(QPixmap_path))
		# Push buttogn signal function setting-up
		self.PB_report           .clicked.connect(self.PB_report_f)
		self.PB_notif_all        .clicked.connect(self.PB_notif_all_f)
		self.PB_drink            .clicked.connect(self.PB_drink_f)
		self.PB_connect_nrf      .clicked.connect(self.PB_connect_nrf_f)
		self.PB_save             .clicked.connect(self.PB_save_f)
		self.PB_import           .clicked.connect(self.PB_import_f)
		self.PB_set_name         .clicked.connect(self.PB_set_name_f)

		# instanciate main processing object
		self.overview_processing = OverviewProcessing()
		self.empl_dict_disp = dict()
		# try a first connection to the nrf

		self.timer = QtCore.QTimer()
		# self.timer.timeout.connect(self.update)
		self.timer.start(3000) #trigger every sec.
		self.timer.timeout.connect(self.timer_refresh_UI)

		self.current_employee_addr = ""

		connect_nrf(self)

		print("\n################# OVERVIEW Starting #################\n\n\r")

	###########################################################################
	# Class functions
	##
	def handleButtonClicked(self, button):
		for item in self.buttonGroup.buttons():
			if button is item:
				PB_employee_f(self, item.objectName())

	def PB_report_f(self):
		pass

	def PB_notif_all_f(self):
		pass

	def PB_drink_f(self):
		pass

	def PB_connect_nrf_f(self):
		connect_nrf(self)

	def PB_set_path_f(self):
		set_config_file(self)

	def PB_set_name_f(self):
		showDial(self)

	def PB_save_f(self):
		save_config(self)

	def PB_import_f(self):
		import_config(self)

	def timer_refresh_UI(self):
		refresh_UI(self)
###############################################################################
## end class MyMainWindow #####################################################
###############################################################################

#function to display another form
def showDial(M_W):
	if (M_W.current_employee_addr == ""):
			print("no employee selected")
	else:
		text, okPressed = QtWidgets.QInputDialog.getText(M_W, "",
							"Employee name:", QtWidgets.QLineEdit.Normal, "")
		if okPressed and text != '':
			if (M_W.current_employee_addr != ""):
				M_W.overview_processing.config_employee.employee_dict[ \
									M_W.current_employee_addr].name = text

## check the message queue and process its messages
def refresh_UI(M_W):
	refresh_all_cnt = 0
	# refresh_node(M_W)
	# refresh_all_cnt = (refresh_all_cnt + 1) % 5
	# if (not refresh_all_cnt):
	refresh_all(M_W)

def refresh_node(M_W):
	pass

def refresh_all(M_W):
	M_W.empl_dict = dict(M_W.overview_processing.config_employee.employee_dict)
	for empl_key in list(M_W.empl_dict):
		empl_value = M_W.empl_dict[empl_key]
		if empl_key not in M_W.empl_dict_disp:
			M_W.empl_dict_disp[empl_key] = empl_value
			add_push_button(M_W, str(empl_key), empl_value)
		else:
			M_W.empl_dict_disp[empl_key] = empl_value
			refresh_push_button(M_W, str(empl_key), empl_value)
		if (empl_key == M_W.current_employee_addr):
			PB_employee_f(M_W, empl_key)

def add_push_button(M_W, button_name, employee):
	BT_name = button_name
	empl_button = QtWidgets.QPushButton(BT_name, M_W.SAWidget_employee_list)
	empl_button.setObjectName(BT_name)
	empl_button_txt = str(employee.name) + " " + \
							str(int(employee.dehydration))
	empl_button.setText(empl_button_txt)
	M_W.verticalLayout.addWidget(empl_button)
	# link each employee buttons to its function
	for button in M_W.VGB_employees.findChildren(QtWidgets.QPushButton):
		if (M_W.buttonGroup.id(button) < 0):
			M_W.buttonGroup.addButton(button)

def refresh_push_button(M_W, button_name, employee):
	for button in M_W.VGB_employees.findChildren(QtWidgets.QPushButton):
		if (button.objectName() == button_name):
			empl_button_txt = str(employee.name) + " " + \
						str(int(employee.dehydration))
			button.setText(empl_button_txt)

def PB_employee_f(M_W, PB_name):
	employee = M_W.empl_dict[PB_name]
	update_selected_employee_info(	M_W,
									employee.name,
									PB_name,
									employee.dehydration,
									employee.temperature,
									employee.humidity)

###############################################################################
## Test and Connect the serial UART connection
##
def connect_nrf(M_W):
	ret = M_W.overview_processing.nrf_serial.connect_nrf()
	if (ret):
		M_W.LB_status_val.setText("Connected")
	else:
		M_W.LB_status_val.setText("Not Connected")

###############################################################################
## Send a test message
##
def send_dummy(M_W):
	ret = M_W.overview_processing.nrf_serial.send_dummy()
	M_W.overview_processing.list_employee()

###############################################################################
## Update the labels containing the info of the current
## selected employee
## arg number: employee number
## arg name: employee name
## arg dehydration: employee dehydration number
##
def update_selected_employee_info(M_W, name, address, dehydration ,
														temperature, humidity):
	M_W.current_employee_addr  = address
	M_W.LB_name_val        .setText(name)
	M_W.LB_select_val      .setText(str(address))
	M_W.LB_dehydration_val .setText(str(int(dehydration)))
	M_W.LB_temperature_val .setText(str(int(temperature)))
	M_W.LB_humidity_val    .setText(str(int(humidity)))

def save_config(M_W):
	save_path = QtWidgets.QFileDialog.getSaveFileName()
	if (save_path[0] != ""):
		M_W.overview_processing.config_employee.save_config(save_path[0])

def import_config(M_W):
	import_path = QtWidgets.QFileDialog.getOpenFileName()
	if (import_path[0] != ""):
		M_W.overview_processing.config_employee.import_config(import_path[0])

# ###############################################################################
# ## Set the led of the selected employee
# ## arg number: employee number
# ##
# def set_led(M_W, number):
# 	global toggle
# 	r_msg = C_F.nrf_set_led(M_W.nrf52_serial, number, toggle)
# 	toggle = not toggle
# 	if (r_msg == None):
# 		connect_nrf(M_W)

# ###############################################################################
# ## Notif drink
# ##
# def notif_drink(M_W):
# 	if (is_serial_connected(M_W)):
# 		return_msg  = S_I.send_read_poll(
# 									M_W.nrf52_serial, "c02560123\r")
# 	else:
# 		print("serial not connected")


###############################################################################
## MAIN
##
def main():
	app = QApplication(sys.argv)
	w   = MyMainWindow()
	w.show()
	sys.exit(app.exec_())


if __name__ == '__main__':
    main()
