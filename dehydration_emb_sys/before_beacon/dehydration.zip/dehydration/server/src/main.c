/* Copyright (c) 2010 - 2017, Nordic Semiconductor ASA
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 4. This software, with or without modification, must only be used with a
 *    Nordic Semiconductor ASA integrated circuit.
 *
 * 5. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdint.h>
#include <string.h>

/* HAL */
#include "nrf.h"
#include "boards.h"
#include "nrf_mesh_sdk.h"
#include "nrf_delay.h"
#include "simple_hal.h"

/* Core */
#include "nrf_mesh.h"
#include "nrf_mesh_events.h"
#include "log.h"

#include "access.h"
#include "access_config.h"
#include "device_state_manager.h"
#include "nrf_mesh_node_config.h"

#include "dehydration_common.h"
#include "dehydration_server.h"

#include "light_switch_example_common.h"

#include "nrf_drv_saadc.h"
#include "nrf_drv_ppi.h"
#include "nrf_drv_timer.h"

/*****************************************************************************
 * Definitions
 *****************************************************************************/

#define LED_PIN_NUMBER (BSP_LED_0)
#define LED_PIN_MASK   (1u << LED_PIN_NUMBER)

#define SAMPLES_IN_BUFFER 1

/*****************************************************************************
 * Static data
 *****************************************************************************/
volatile uint8_t state = 1;

static const nrf_drv_timer_t m_timer = NRF_DRV_TIMER_INSTANCE(2);
static nrf_saadc_value_t     m_buffer_pool[2][SAMPLES_IN_BUFFER];
static nrf_ppi_channel_t     m_ppi_channel;
static uint32_t              m_adc_evt_counter;
static dehydration_server_t m_server;

static int16_t Dehydration_state;
static int16_t Humidity_state;
static int16_t Temperature_state;
//static uint8_t Name_state[NAME_OP_LENGHT * NAME_CHAR_PER_PACKET];

/* Forward declaration */
static uint32_t get_cb(const dehydration_server_t * p_server, uint32_t key, uint32_t val);
static uint32_t set_cb(const dehydration_server_t * p_server, uint32_t key, uint32_t val);

 /*8888b.   .d88888b.  888b    888 8888888888 
d88P  Y88b d88P" "Y88b 8888b   888 888        
888    888 888     888 88888b  888 888        
888        888     888 888Y88b 888 8888888    
888        888     888 888 Y88b888 888        
888    888 888     888 888  Y88888 888        
Y88b  d88P Y88b. .d88P 888   Y8888 888        
 "Y8888P"   "Y88888P"  888    Y888 8*/

static void configuration_setup(void * p_unused)
{
    __LOG(LOG_SRC_APP, LOG_LEVEL_INFO, "Initializing and adding models\n");
    m_server.get_cb = get_cb;
    m_server.set_cb = set_cb;
    ERROR_CHECK(dehydration_server_init(&m_server, 0));
    ERROR_CHECK(access_model_subscription_list_alloc(m_server.model_handle));
    hal_led_mask_set(LEDS_MASK, true); 
}


/*88888b.  8888888b.   .d88888b.  888     888 
888   Y88b 888   Y88b d88P" "Y88b 888     888 
888    888 888    888 888     888 888     888 
888   d88P 888   d88P 888     888 Y88b   d88P 
8888888P"  8888888P"  888     888  Y88b d88P  
888        888 T88b   888     888   Y88o88P   
888        888  T88b  Y88b. .d88P    Y888P    
888        888   T88b  "Y88888P"      Y*/

static void provisioning_complete(void * p_unused)
{
    __LOG(LOG_SRC_APP, LOG_LEVEL_INFO, "Successfully provisioned\n");
    hal_led_mask_set(LEDS_MASK, false);
    hal_led_blink_ms(LED_PIN_MASK, 200, 4);
}


 /*8888b.  8888888888 88888888888 
d88P  Y88b 888            888     
888    888 888            888     
888        8888888        888     
888  88888 888            888     
888    888 888            888     
Y88b  d88P 888            888     
 "Y8888P"  8888888888     8*/

static uint32_t get_cb(const dehydration_server_t * p_server, uint32_t key, uint32_t val)
{
    __LOG(LOG_SRC_APP, LOG_LEVEL_INFO, "GET callback key = %d, val = %d\n", key, val);
    __LOG(LOG_SRC_APP, LOG_LEVEL_INFO, "Dehydration state: %d\n", Dehydration_state);

    if (key == 3)
      return (uint32_t) Dehydration_state;
    else
      return 0;
}


 /*8888b.  8888888888 88888888888 
d88P  Y88b 888            888     
Y88b.      888            888     
 "Y888b.   8888888        888     
    "Y88b. 888            888     
      "888 888            888     
Y88b  d88P 888            888     
 "Y8888P"  8888888888     8*/

static uint32_t set_cb(const dehydration_server_t * p_server, uint32_t key, uint32_t val)
{
     __LOG(LOG_SRC_APP, LOG_LEVEL_INFO, "SET callback OP_key = %d, val = %d\n", key, val);
    uint32_t return_val = val;

    switch (key)
    {
        case (DEHYDRATION_OP):
            return_val = Dehydration_state;
            break;
        case (HUMIDITY_OP):
            return_val = Humidity_state;
            break;
        case (TEMPERATURE_OP):
            return_val = Temperature_state;
            break;
        case (LED_OP):
            hal_led_pin_set(LED_1, val);
            break;
        case (BUZZER_OP):
            hal_led_pin_set(LED_2, val);
            break;
        default:
            __LOG(LOG_SRC_APP, LOG_LEVEL_INFO, "wrong OP received\n");
            break;
    }

    return return_val;
}


/*888888888 8888888 888b     d888 8888888888 8888888b.  
    888       888   8888b   d8888 888        888   Y88b 
    888       888   88888b.d88888 888        888    888 
    888       888   888Y88888P888 8888888    888   d88P 
    888       888   888 Y888P 888 888        8888888P"  
    888       888   888  Y8P  888 888        888 T88b   
    888       888   888   "   888 888        888  T88b  
    888     8888888 888       888 8888888888 888   T8*/

void timer_handler(nrf_timer_event_t event_type, void * p_context)
{

}


void saadc_sampling_event_init(void)
{
    ret_code_t err_code;

    err_code = nrf_drv_ppi_init();
    APP_ERROR_CHECK(err_code);

    nrf_drv_timer_config_t timer_cfg = NRF_DRV_TIMER_DEFAULT_CONFIG;
    timer_cfg.bit_width = NRF_TIMER_BIT_WIDTH_32;
    err_code = nrf_drv_timer_init(&m_timer, &timer_cfg, timer_handler);
    APP_ERROR_CHECK(err_code);

    /* setup m_timer for compare event every 400ms */
    uint32_t ticks = nrf_drv_timer_ms_to_ticks(&m_timer, 2000);
    nrf_drv_timer_extended_compare(&m_timer,
                                   NRF_TIMER_CC_CHANNEL0,
                                   ticks,
                                   NRF_TIMER_SHORT_COMPARE0_CLEAR_MASK,
                                   false);
    nrf_drv_timer_enable(&m_timer);

    uint32_t timer_compare_event_addr = nrf_drv_timer_compare_event_address_get(&m_timer,
                                                                                NRF_TIMER_CC_CHANNEL0);
    uint32_t saadc_sample_task_addr   = nrf_drv_saadc_sample_task_get();

    /* setup ppi channel so that timer compare event is triggering sample task in SAADC */
    err_code = nrf_drv_ppi_channel_alloc(&m_ppi_channel);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_ppi_channel_assign(m_ppi_channel,
                                          timer_compare_event_addr,
                                          saadc_sample_task_addr);
    APP_ERROR_CHECK(err_code);
}


 /*8888b.         d8888        d8888 8888888b.   .d8888b.  
d88P  Y88b       d88888       d88888 888  "Y88b d88P  Y88b 
Y88b.           d88P888      d88P888 888    888 888    888 
 "Y888b.       d88P 888     d88P 888 888    888 888        
    "Y88b.    d88P  888    d88P  888 888    888 888        
      "888   d88P   888   d88P   888 888    888 888    888 
Y88b  d88P  d8888888888  d8888888888 888  .d88P Y88b  d88P 
 "Y8888P"  d88P     888 d88P     888 8888888P"   "Y8888*/

void saadc_sampling_event_enable(void)
{
    ret_code_t err_code = nrf_drv_ppi_channel_enable(m_ppi_channel);

    ERROR_CHECK(err_code);
}


void saadc_callback(nrf_drv_saadc_evt_t const * p_event)
{
    if (p_event->type == NRF_DRV_SAADC_EVT_DONE)
    {
        ret_code_t err_code;

        err_code = nrf_drv_saadc_buffer_convert(p_event->data.done.p_buffer, SAMPLES_IN_BUFFER);
        ERROR_CHECK(err_code);

        int i = 0;
//        __LOG(LOG_SRC_APP, LOG_LEVEL_INFO, "ADC event number: %d\n", (int)m_adc_evt_counter);
//
//        for (i = 0; i < SAMPLES_IN_BUFFER; i++)
//        {
//            __LOG(LOG_SRC_APP, LOG_LEVEL_INFO, "%d\n", p_event->data.done.p_buffer[i]);
//        }
//        m_adc_evt_counter++;

        Dehydration_state = p_event->data.done.p_buffer[i];
        Humidity_state    = Dehydration_state / 4;
        Temperature_state = Dehydration_state * 3;
    }
}


void saadc_init(void)
{
    ret_code_t err_code;
    nrf_saadc_channel_config_t channel_config =
        NRF_DRV_SAADC_DEFAULT_CHANNEL_CONFIG_SE(NRF_SAADC_INPUT_AIN0);

    err_code = nrf_drv_saadc_init(NULL, saadc_callback);
    ERROR_CHECK(err_code);

    err_code = nrf_drv_saadc_channel_init(0, &channel_config);
    ERROR_CHECK(err_code);

    err_code = nrf_drv_saadc_buffer_convert(m_buffer_pool[0], SAMPLES_IN_BUFFER);
    ERROR_CHECK(err_code);

    err_code = nrf_drv_saadc_buffer_convert(m_buffer_pool[1], SAMPLES_IN_BUFFER);
    ERROR_CHECK(err_code);

}


/*8b     d888        d8888 8888888 888b    888 
8888b   d8888       d88888   888   8888b   888 
88888b.d88888      d88P888   888   88888b  888 
888Y88888P888     d88P 888   888   888Y88b 888 
888 Y888P 888    d88P  888   888   888 Y88b888 
888  Y8P  888   d88P   888   888   888  Y88888 
888   "   888  d8888888888   888   888   Y8888 
888       888 d88P     888 8888888 888    Y8*/

int main(void)
{
    __LOG_INIT(LOG_SRC_APP | LOG_SRC_ACCESS, LOG_LEVEL_INFO, LOG_CALLBACK_DEFAULT);
    __LOG(LOG_SRC_APP, LOG_LEVEL_INFO, "----- BLE Mesh Dehydration Server  -----\n");

    hal_leds_init();

    static const uint8_t static_auth_data[NRF_MESH_KEY_SIZE] = STATIC_AUTH_DATA;
    static nrf_mesh_node_config_params_t config_params =
        {.prov_caps = NRF_MESH_PROV_OOB_CAPS_DEFAULT(ACCESS_ELEMENT_COUNT)};
    config_params.p_static_data     = static_auth_data;
    config_params.complete_callback = provisioning_complete;
    config_params.setup_callback    = configuration_setup;
    config_params.irq_priority      = NRF_MESH_IRQ_PRIORITY_LOWEST;

#if defined(S110)
    config_params.lf_clk_cfg = NRF_CLOCK_LFCLKSRC_XTAL_20_PPM;
#elif SD_BLE_API_VERSION >= 5
    config_params.lf_clk_cfg.source   = NRF_CLOCK_LF_SRC_XTAL;
    config_params.lf_clk_cfg.accuracy = NRF_CLOCK_LF_ACCURACY_20_PPM;
#else
    config_params.lf_clk_cfg.source        = NRF_CLOCK_LF_SRC_XTAL;
    config_params.lf_clk_cfg.xtal_accuracy = NRF_CLOCK_LF_XTAL_ACCURACY_20_PPM;
#endif

    ERROR_CHECK(nrf_mesh_node_config(&config_params));

    saadc_init();
    saadc_sampling_event_init();
    saadc_sampling_event_enable();

    __LOG(LOG_SRC_APP, LOG_LEVEL_INFO, "INFINITE LOOP SERVER\n");

    while (true)
    {   
       (void)sd_app_evt_wait();
    }


}
