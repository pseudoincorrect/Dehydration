#ifndef __COMMAND_DEF_H__
#define __COMMAND_DEF_H__

//Mesh OP side
#define KEY_SIZE 	4
#define VAL_SIZE 	4
#define SERVER_SIZE     4

// UART Side
#define CMD_LENGHT 	  1
#define SERVER_LENGHT     SERVER_SIZE
#define VAL_LENGHT 	  VAL_SIZE

// UART Commands
#define PORT_TEST_MSG 	  'a' 
#define GET_DEHYDRATION   'b' 
#define GET_HUMIDITY 	  'c'
#define GET_TEMPERATURE   'd'
#define SET_LED           'e'
#define SET_BUZZER        'f'
#define GET_NODES         'o'

#define IS_OP     1 // means the key is processed as mesh OP
#define IS_NOT_OP 0 // or not (as a UART command)

typedef enum
{
    COMMAND_ERROR,
    NO_WAIT, 
    WAIT_REPLY
} command_return_t;

#endif